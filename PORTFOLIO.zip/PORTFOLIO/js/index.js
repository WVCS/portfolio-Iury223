function openMenu() {
  document.querySelector(".menu-overlay").style.opacity = "1";
  document.querySelector(".menu-overlay").style.display = "block";
  document.querySelector(".red-section").style.backgroundColor  = "transparent";
  document.querySelector(".white-section").style.backgroundColor  = "transparent";
  document.querySelector(".head").style.backgroundImage  = "url(img/head-menu.jpg";
  document.querySelector(".menu-btn-close").style.display  = "block";
  document.querySelector(".menu-btn").style.display  = "none";
  document.querySelector(".head").style.backgroundColor  = "white";
}
function closeMenu(){
   document.querySelector(".head").style.backgroundImage  = "url(img/head-main.svg";
  document.querySelector(".menu-overlay").style.display = "none";
  document.querySelector(".red-section").style.backgroundColor  = "transparent";
  document.querySelector(".white-section").style.backgroundColor  = "transparent";
  document.querySelector(".menu-btn-close").style.display  = "none";
  document.querySelector(".menu-btn").style.display  = "block";
}
