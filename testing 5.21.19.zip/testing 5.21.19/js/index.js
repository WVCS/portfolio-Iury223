var menuStatus = false;
var flexStatus = false;
 var midY = window.innerHeight/2;
  var midX = window.innerWidth/2;
$(function() {
  //unAnimating the text from the screen
    $('.clickMe').on('click', function() {
        $('.glitchy').animate({
          opacity: 0
        }, 200,);

      $('.clickMe').fadeOut(200);

        $('.box-glitch').animate({
          top: midY,
          left: midX,
          height: '100px',
          width: '100px',
          'border-radius': '50px'
        }, 500)
        .animate({
          top: 0,
          opacity: 0
        }, 300, function(){
          console.log('hi');
          menuStatus = true;
          console.log(menuStatus);
          if(menuStatus === true){
            animateName();
        }
        });
      function animateName(){
        $('.myName').animate({
          padding: midX,
        }, 500)
        .animate({
          'font-size': '200px',
          opacity: 1,
        }, 500)
        .delay(500).animate({
          padding: 0
        }, 500)

      }
  });
});
