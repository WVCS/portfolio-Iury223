  $(function() {
    $('.clickMe').on('click', function() {
        // FadeIn Code Goes Here
        $('.glitchy').animate({
          opacity: 0
        }, 300, function(){
          $('.clickMe').fadeOut(100);
        });
        $('.box-glitch').animate({
          height: '0px',
        }, 500);
        $('.myName').fadeIn(700);
    });
});
